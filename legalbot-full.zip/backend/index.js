require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Low, JSONFile } = require('lowdb');
const multer = require('multer');
const axios = require('axios');
const { nanoid } = require('nanoid');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// lowdb setup
const dbFile = path.join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

async function initDb(){ await db.read(); db.data = db.data || { users: [], tickets: [] }; await db.write(); }
initDb();

const JWT_SECRET = process.env.JWT_SECRET || 'secret-demo';

// Multer for attachments
const uploadDir = path.join(__dirname, 'uploads');
if(!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const storage = multer.diskStorage({
  destination: (req,file,cb)=>cb(null, uploadDir),
  filename: (req,file,cb)=>cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Helpers
function authMiddleware(req,res,next){
  const hdr = req.headers.authorization;
  if(!hdr) return res.status(401).json({error:'missing auth'});
  const token = hdr.replace('Bearer ','');
  try{
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  }catch(e){ return res.status(401).json({error:'invalid token'}); }
}

// Register
app.post('/api/register', async (req,res)=>{
  const { username, password } = req.body;
  await db.read();
  if(db.data.users.find(u=>u.username===username)) return res.status(400).json({error:'user exists'});
  const hash = await bcrypt.hash(password,10);
  const user = { id: 'u_'+nanoid(8), username, password: hash, role:'user' };
  db.data.users.push(user);
  await db.write();
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ user:{id:user.id,username:user.username,role:user.role}, token });
});

// Login
app.post('/api/login', async (req,res)=>{
  const { username, password } = req.body;
  await db.read();
  const user = db.data.users.find(u=>u.username===username);
  if(!user) return res.status(401).json({error:'invalid credentials'});
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(401).json({error:'invalid credentials'});
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ user:{id:user.id,username:user.username,role:user.role}, token });
});

// Get current user
app.get('/api/me', authMiddleware, async (req,res)=>{
  await db.read();
  const user = db.data.users.find(u=>u.id===req.user.id);
  res.json({ id:user.id, username:user.username, role:user.role });
});

// Tickets CRUD + comments + escalate
app.get('/api/tickets', authMiddleware, async (req,res)=>{
  await db.read();
  // users get their tickets, admins get all
  const user = req.user;
  const tickets = user.role==='admin' ? db.data.tickets : db.data.tickets.filter(t=>t.createdBy===user.id || t.assignedTo===user.id);
  res.json(tickets);
});

app.post('/api/tickets', authMiddleware, upload.array('attachments',5), async (req,res)=>{
  await db.read();
  const { title, description, priority='normal' } = req.body;
  const attachments = (req.files||[]).map(f=>({ filename: f.filename, originalname: f.originalname, path: '/uploads/'+f.filename }));
  const ticket = {
    id: 't_'+nanoid(8),
    title, description, priority,
    status: 'open',
    createdBy: req.user.id,
    assignedTo: null,
    comments: [],
    attachments,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    history: [{ at: new Date().toISOString(), action: 'created', by: req.user.id }]
  };
  db.data.tickets.push(ticket);
  await db.write();
  res.json(ticket);
});

app.get('/api/tickets/:id', authMiddleware, async (req,res)=>{
  await db.read();
  const t = db.data.tickets.find(x=>x.id===req.params.id);
  if(!t) return res.status(404).json({error:'not found'});
  res.json(t);
});

app.post('/api/tickets/:id/comment', authMiddleware, async (req,res)=>{
  const { text } = req.body;
  await db.read();
  const t = db.data.tickets.find(x=>x.id===req.params.id);
  if(!t) return res.status(404).json({error:'not found'});
  const c = { id: 'c_'+nanoid(6), text, by: req.user.id, at: new Date().toISOString() };
  t.comments.push(c);
  t.updatedAt = new Date().toISOString();
  t.history.push({ at: new Date().toISOString(), action: 'comment', by: req.user.id });
  await db.write();
  res.json(c);
});

app.post('/api/tickets/:id/escalate', authMiddleware, async (req,res)=>{
  await db.read();
  const t = db.data.tickets.find(x=>x.id===req.params.id);
  if(!t) return res.status(404).json({error:'not found'});
  t.priority = 'high';
  t.history.push({ at: new Date().toISOString(), action: 'escalated', by: req.user.id });
  t.updatedAt = new Date().toISOString();
  await db.write();
  res.json(t);
});

app.post('/api/tickets/:id/status', authMiddleware, async (req,res)=>{
  const { status } = req.body;
  await db.read();
  const t = db.data.tickets.find(x=>x.id===req.params.id);
  if(!t) return res.status(404).json({error:'not found'});
  t.status = status;
  t.history.push({ at: new Date().toISOString(), action: 'status:'+status, by: req.user.id });
  t.updatedAt = new Date().toISOString();
  await db.write();
  res.json(t);
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname,'uploads')));

// Chat endpoint (Gemini proxy adapter)
app.post('/api/chat', authMiddleware, async (req,res)=>{
  const { message, conversationId } = req.body;
  // Basic safety check - block explicit illegal instructions
  if(/kill|bomb|poison|illegal|commit a crime/i.test(message)) {
    return res.status(400).json({ error: 'Blocked content' });
  }

  const apiKey = process.env.GEMINI_API_KEY || '';
  const apiUrl = process.env.GEMINI_API_URL || '';

  if(!apiKey || !apiUrl){
    // Better canned response if not configured
    return res.json({ reply: "Gemini not configured. To enable AI replies, set GEMINI_API_KEY and GEMINI_API_URL in .env." });
  }

  try{
    // Example payload - adapt to provider schema
    const payload = { model: "gemini-2.0-flash", input: message, conversation: conversationId || null };
    const response = await axios.post(apiUrl, payload, {
      headers:{ Authorization: `Bearer ${apiKey}`, 'Content-Type':'application/json' },
      timeout: 25000
    });
    const reply = response.data?.output?.text || response.data?.reply || JSON.stringify(response.data);
    res.json({ reply });
  }catch(err){
    console.error('chat proxy err', err?.toString?.());
    res.status(500).json({ error: 'AI provider error', details: err?.message || String(err) });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Backend listening on', PORT));
