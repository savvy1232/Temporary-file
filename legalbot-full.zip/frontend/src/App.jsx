import React, { useEffect, useState } from 'react';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('lb_token') || null);
  const [user, setUser] = useState(null);
  const [showRegister, setShowRegister] = useState(false);

  useEffect(()=>{
    if(token){
      fetch('/api/me', { headers:{ Authorization:'Bearer '+token } }).then(r=>r.json()).then(data=>{
        if(data?.username) setUser(data);
        else { setToken(null); localStorage.removeItem('lb_token'); }
      }).catch(()=>{ setToken(null); localStorage.removeItem('lb_token'); });
    }
  },[token]);

  function onLogin(userObj, tokenStr){
    setUser(userObj); setToken(tokenStr); localStorage.setItem('lb_token', tokenStr);
  }
  function logout(){ setUser(null); setToken(null); localStorage.removeItem('lb_token'); }

  if(!token) {
    return showRegister ? <Register onBack={()=>setShowRegister(false)} onRegister={onLogin} /> : <Login onRegister={()=>setShowRegister(true)} onLogin={onLogin} />;
  }
  return <Dashboard token={token} user={user} onLogout={logout} />;
}
