import React, { useState } from 'react';
import axios from 'axios';

export default function TicketsPanel({ token, tickets, refresh }){
  const [title,setTitle]=useState(''); const [desc,setDesc]=useState('');
  const [file,setFile]=useState(null);

  async function create(){
    if(!title) return;
    const fd = new FormData();
    fd.append('title', title);
    fd.append('description', desc);
    if(file) fd.append('attachments', file);
    await axios.post('http://localhost:4000/api/tickets', fd, { headers:{ Authorization:'Bearer '+token, 'Content-Type':'multipart/form-data' }});
    setTitle(''); setDesc(''); setFile(null);
    refresh && refresh();
  }

  async function escalate(id){ await axios.post(`http://localhost:4000/api/tickets/${id}/escalate`, {}, { headers:{ Authorization:'Bearer '+token }}); refresh&&refresh(); }
  async function setStatus(id,s){ await axios.post(`http://localhost:4000/api/tickets/${id}/status`, { status:s }, { headers:{ Authorization:'Bearer '+token }}); refresh&&refresh(); }

  return (
    <div className="card" style={{position:'sticky',top:20}}>
      <div style={{marginBottom:12}}><strong>Tickets</strong><div className="small">Create and manage support tickets</div></div>
      <div className="form-field"><input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} /></div>
      <div className="form-field"><textarea placeholder="Description" rows={3} value={desc} onChange={e=>setDesc(e.target.value)} /></div>
      <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:12}}>
        <input type="file" onChange={e=>setFile(e.target.files[0])} />
        <button className="btn" onClick={create}>Create</button>
      </div>

      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        {tickets.length===0 && <div className="small">No tickets yet</div>}
        {tickets.map(t=>(
          <div key={t.id} className="ticket">
            <div className="ticket-row">
              <div style={{fontWeight:700}}>{t.title}</div>
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <div className={`pill ${t.priority==='high'?'escalated':''} ${t.status==='open'?'open':''} ${t.status==='closed'?'closed':''}`}>{t.priority} • {t.status}</div>
                <button className="btn" onClick={()=>escalate(t.id)}>Escalate</button>
                <button className="btn" onClick={()=>setStatus(t.id,'closed')}>Close</button>
              </div>
            </div>
            <div className="small">{t.description}</div>
            {t.attachments?.length>0 && <div className="small">Attachments: {t.attachments.map(a=>a.originalname||a.filename).join(', ')}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
