import React, { useEffect, useState } from 'react';
import TicketsPanel from './TicketsPanel';
import ChatPanel from './ChatPanel';
import axios from 'axios';

export default function Dashboard({ token, user, onLogout }){
  const [tickets, setTickets] = useState([]);
  useEffect(()=>{ fetchTickets(); },[]);

  async function fetchTickets(){
    const res = await axios.get('http://localhost:4000/api/tickets', { headers:{ Authorization:'Bearer '+token }});
    setTickets(res.data);
  }

  return (
    <div className="app">
      <div className="blob b1"></div>
      <div className="blob b2"></div>
      <div className="container">
        <div>
          <header className="app-header card">
            <div className="brand"><div className="logo">LB</div><h1>LegalBot</h1></div>
            <div style={{display:'flex',gap:12,alignItems:'center'}}>
              <div className="small">Signed in as <strong>{user?.username}</strong></div>
              <button className="btn" onClick={onLogout}>Logout</button>
            </div>
          </header>

          <div className="card" style={{marginTop:12}}>
            <ChatPanel token={token} />
          </div>
        </div>

        <aside>
          <TicketsPanel token={token} tickets={tickets} refresh={fetchTickets} />
        </aside>
      </div>
    </div>
  );
}
