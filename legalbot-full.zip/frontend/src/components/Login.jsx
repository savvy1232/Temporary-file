import React, { useState } from 'react';
import axios from 'axios';

export default function Login({ onLogin, onRegister }){
  const [username,setUsername]=useState('');
  const [password,setPassword]=useState('');
  const [err,setErr]=useState('');

  async function submit(e){ e.preventDefault(); setErr(''); try{
    const res = await axios.post('http://localhost:4000/api/login',{username,password});
    onLogin(res.data.user, res.data.token);
  }catch(err){ setErr(err.response?.data?.error || 'Login failed'); }
  }

  return (
    <div className="card login-box">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <div>
          <div className="brand"><div className="logo">LB</div><h1>LegalBot</h1></div>
          <div className="small">Secure legal assistant — demo</div>
        </div>
        <div>
          <button className="btn" onClick={onRegister}>Register</button>
        </div>
      </div>

      <form onSubmit={submit}>
        <div className="form-field"><label className="small">Username</label><input value={username} onChange={e=>setUsername(e.target.value)} required /></div>
        <div className="form-field"><label className="small">Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></div>
        {err && <div style={{color:'#ffb3b3'}}>{err}</div>}
        <div style={{display:'flex',justifyContent:'flex-end',marginTop:8}}><button className="btn" type="submit">Login</button></div>
      </form>
    </div>
  );
}
