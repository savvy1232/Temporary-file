import React, { useRef, useState } from 'react';
import axios from 'axios';

export default function ChatPanel({ token }){
  const [messages, setMessages] = useState([{role:'bot',text:'Hello — how can I help with your legal question today?'}]);
  const [input, setInput] = useState('');
  const convo = useRef(null);

  async function send(){
    if(!input) return;
    setMessages(m=>[...m,{role:'user',text:input}]);
    try{
      const res = await axios.post('http://localhost:4000/api/chat',{ message: input, conversationId: convo.current }, { headers:{ Authorization:'Bearer '+token }});
      const reply = res.data.reply || 'No reply';
      setMessages(m=>[...m,{role:'bot',text:reply}]);
    }catch(err){
      setMessages(m=>[...m,{role:'bot',text:'Error: could not contact AI service.'}]);
    }
    setInput('');
  }

  return (
    <div className="chat">
      <div style={{padding:12,borderBottom:'1px solid rgba(255,255,255,0.03)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div><strong>Legal Assistant</strong><div className="small">AI-powered answers — not legal advice</div></div>
      </div>
      <div className="chat-messages">
        {messages.map((m,i)=>(<div key={i} className={`bubble ${m.role==='user'?'user':''}`}>{m.text}</div>))}
      </div>
      <div style={{display:'flex',gap:8,padding:10,borderTop:'1px solid rgba(255,255,255,0.03)'}}>
        <input style={{flex:1}} value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask a legal question..." />
        <button className="btn" onClick={send}>Send</button>
      </div>
    </div>
  );
}
