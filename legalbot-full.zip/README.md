# LegalBot — Full Example

This repo contains a fuller-featured implementation of the LegalBot live chat + ticketing system.

Features implemented:
- Express backend with JWT auth, bcrypt password hashing.
- Persistent JSON DB using lowdb (file: backend/db.json).
- Ticketing with attachments, comments, escalation, status, history.
- React frontend with Register/Login, Dashboard, Chat, Tickets.
- Gemini proxy adapter (configure GEMINI_API_KEY and GEMINI_API_URL in backend/.env).

Security & production notes:
- This is still an example. For production: use a real DB (Postgres/Mongo), HTTPS, proper secret management, input validation, rate-limiting, and logging.
- The admin user is included in db.json (username: admin, password: admin123) — change immediately.

Setup:
1. Backend:
   - cd backend
   - cp .env.example .env and set values
   - npm install
   - npm run dev
2. Frontend:
   - cd frontend
   - npm install
   - npm run start
3. Open http://localhost:3000
